import React, { useEffect, useState, useRef, useCallback } from "react";
import axios from "axios";
import { showDesktopNotification } from "../../utils/notifications";
import { playNotificationSound } from "@/utils/notificationSound";
import websocket from "../../utils/websocket"; // ADD THIS IMPORT
import { Bell, Check, Clock, User } from "lucide-react";

export default function NotificationBell({ userId }) {
  const [notifications, setNotifications] = useState([]);
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);
  
  // Remove SSE refs and add WebSocket ref
  const wsInitializedRef = useRef(false);

  const unreadCount = notifications.filter(n => n.is_read == 0).length;

  // ... (keep your existing formatTime and formatDetailedDateTime functions)

  /* ---------------- WEB SOCKET CONNECTION ---------------- */
  useEffect(() => {
    console.log("🔄 WebSocket useEffect triggered, userId:", userId);
    
    if (!userId) {
      console.log("❌ WebSocket: No userId provided");
      return;
    }

    // Connect WebSocket
    websocket.connect(userId);

    // Listen for notifications
    const unsubscribeNotification = websocket.on('notification', (notification) => {
      console.log("📨 WebSocket: Notification received:", notification);
      
      // Update notifications list
      setNotifications(prev => [notification, ...prev]);
      
      // Play sound
      playNotificationSound();
      
      // Show desktop notification
      console.log("🔔 WebSocket: Calling showDesktopNotification");
      showDesktopNotification(notification);
    });

    // Listen for connection events
    const unsubscribeConnected = websocket.on('connected', () => {
      console.log("✅ WebSocket: Connected event received");
      wsInitializedRef.current = true;
    });

    const unsubscribeDisconnected = websocket.on('disconnected', () => {
      console.log("⚠️ WebSocket: Disconnected event received");
      wsInitializedRef.current = false;
    });

    // Cleanup on unmount
    return () => {
      unsubscribeNotification();
      unsubscribeConnected();
      unsubscribeDisconnected();
      
      // Don't disconnect WebSocket - keep it alive for the whole app
      // The WebSocketManager singleton will manage reconnections
    };
  }, [userId]);

  /* ---------------- FETCH NOTIFICATIONS (ONLY ON MOUNT) ---------------- */
  useEffect(() => {
    if (!userId) return;
    
    const fetchNotifications = async () => {
      try {
        const res = await axios.get(
          `${import.meta.env.VITE_API_URL}api/notifications.php?user_id=${userId}`
        );
        setNotifications(res.data.data || []);
      } catch (err) {
        console.error("Error fetching notifications:", err);
      }
    };
    
    fetchNotifications();
    
    // Remove polling - WebSocket will handle real-time updates
  }, [userId]);

  // ... (keep your existing markRead and markAllAsRead functions)

  // ... (keep your existing render/return statement)
}