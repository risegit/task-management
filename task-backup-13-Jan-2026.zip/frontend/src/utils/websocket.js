class WebSocketManager {
  constructor() {
    this.socket = null;
    this.userId = null;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.reconnectDelay = 1000;
    this.listeners = new Map();
    this.isConnected = false;
    this.heartbeatInterval = null;
  }

  connect(userId) {
    if (!userId) {
      console.error('WebSocket: User ID required');
      return;
    }

    if (this.socket && this.userId === userId && this.isConnected) {
      console.log('WebSocket: Already connected');
      return;
    }

    // Close existing connection
    this.disconnect();

    this.userId = userId;
    
    // Determine WebSocket URL based on environment
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = import.meta.env.VITE_WS_HOST || window.location.hostname;
    const port = import.meta.env.VITE_WS_PORT || '8080';
    const wsUrl = `${protocol}//${host}:${port}/api/websocket-server.php?user_id=${userId}`;
    
    console.log('WebSocket: Connecting to', wsUrl);
    
    this.socket = new WebSocket(wsUrl);
    
    this.socket.onopen = () => {
      console.log('✅ WebSocket: Connected successfully');
      this.isConnected = true;
      this.reconnectAttempts = 0;
      this.startHeartbeat();
      this.emit('connected');
    };
    
    this.socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'pong') {
          // Heartbeat response, do nothing
          return;
        }
        
        if (data.type === 'notification') {
          this.emit('notification', data.data);
        }
        
        // Forward all messages
        this.emit('message', data);
      } catch (error) {
        console.error('WebSocket: Error parsing message:', error);
      }
    };
    
    this.socket.onerror = (error) => {
      console.error('❌ WebSocket: Connection error:', error);
      this.emit('error', error);
    };
    
    this.socket.onclose = (event) => {
      console.log(`⚠️ WebSocket: Disconnected (code: ${event.code}, reason: ${event.reason})`);
      this.isConnected = false;
      this.stopHeartbeat();
      this.emit('disconnected', event);
      
      // Attempt reconnection
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        const delay = this.reconnectDelay * Math.pow(1.5, this.reconnectAttempts);
        console.log(`WebSocket: Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts + 1})`);
        
        setTimeout(() => {
          this.reconnectAttempts++;
          this.connect(this.userId);
        }, delay);
      }
    };
  }

  startHeartbeat() {
    // Clear existing interval
    this.stopHeartbeat();
    
    // Send ping every 30 seconds
    this.heartbeatInterval = setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.send({ type: 'ping' });
      }
    }, 30000);
  }

  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  send(data) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(data));
      return true;
    }
    return false;
  }

  disconnect() {
    this.stopHeartbeat();
    
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    
    this.isConnected = false;
    this.userId = null;
    console.log('WebSocket: Disconnected');
  }

  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
    
    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(event);
      if (callbacks) {
        const index = callbacks.indexOf(callback);
        if (index > -1) {
          callbacks.splice(index, 1);
        }
      }
    };
  }

  emit(event, data) {
    const callbacks = this.listeners.get(event);
    if (callbacks) {
      callbacks.forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`WebSocket: Error in ${event} listener:`, error);
        }
      });
    }
  }
}

// Create a singleton instance
const websocket = new WebSocketManager();

export default websocket;