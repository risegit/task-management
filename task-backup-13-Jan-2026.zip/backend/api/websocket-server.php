<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

require __DIR__ . '/../vendor/autoload.php';

class NotificationServer implements MessageComponentInterface {
    protected $clients;
    protected $userConnections; // Store user_id -> connections mapping

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->userConnections = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection
        $this->clients->attach($conn);
        
        // Parse query string to get user_id
        $queryString = $conn->httpRequest->getUri()->getQuery();
        parse_str($queryString, $queryParams);
        
        $userId = $queryParams['user_id'] ?? null;
        
        if ($userId) {
            // Map user_id to this connection
            $conn->userId = $userId;
            
            if (!isset($this->userConnections[$userId])) {
                $this->userConnections[$userId] = [];
            }
            $this->userConnections[$userId][] = $conn;
            
            echo "New connection for user {$userId} (ID: {$conn->resourceId})\n";
        } else {
            echo "New connection (ID: {$conn->resourceId}) - No user ID\n";
        }
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        // Parse incoming message (if any from client)
        $data = json_decode($msg, true);
        
        if ($data && isset($data['type'])) {
            switch ($data['type']) {
                case 'ping':
                    // Send pong response
                    $from->send(json_encode(['type' => 'pong']));
                    break;
                    
                case 'mark_read':
                    // Handle mark as read from client
                    // You can forward this to your main PHP app via HTTP
                    break;
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        // Remove connection
        $this->clients->detach($conn);
        
        // Remove from user connections mapping
        if (isset($conn->userId)) {
            $userId = $conn->userId;
            
            if (isset($this->userConnections[$userId])) {
                $this->userConnections[$userId] = array_filter(
                    $this->userConnections[$userId],
                    function($connection) use ($conn) {
                        return $connection !== $conn;
                    }
                );
                
                // If no connections left for this user, remove the entry
                if (empty($this->userConnections[$userId])) {
                    unset($this->userConnections[$userId]);
                }
            }
        }
        
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    // Public method to send notification to specific user
    public function sendToUser($userId, $notification) {
        if (isset($this->userConnections[$userId])) {
            $message = json_encode([
                'type' => 'notification',
                'data' => $notification
            ]);
            
            foreach ($this->userConnections[$userId] as $client) {
                $client->send($message);
            }
            
            return true;
        }
        return false;
    }
}

// Function to start server
function startWebSocketServer() {
    $server = IoServer::factory(
        new HttpServer(
            new WsServer(
                new NotificationServer()
            )
        ),
        8080 // WebSocket port
    );
    
    echo "WebSocket server started on port 8080\n";
    $server->run();
}

// Check if running from command line
if (php_sapi_name() === 'cli') {
    startWebSocketServer();
} else {
    // If accessed via web, show usage instructions
    echo "This is a WebSocket server. Run from command line:\n";
    echo "php websocket-server.php\n";
}

// Add HTTP endpoint to receive push notifications
if (php_sapi_name() !== 'cli') {
    // This runs when accessed via HTTP (for push notifications)
    
    // Simple HTTP endpoint to push notifications
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Verify secret key (for security)
        $secret = $_POST['secret'] ?? '';
        if ($secret !== 'YOUR_SECRET_KEY') {
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        
        $userId = $_POST['user_id'] ?? null;
        $notification = json_decode($_POST['notification'] ?? '{}', true);
        
        if ($userId && $notification) {
            // In a real implementation, you would access the NotificationServer instance
            // This is simplified - in production, use shared memory, Redis, or database
            echo json_encode(['success' => true, 'message' => 'Notification queued']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid data']);
        }
        exit;
    }
}
?>